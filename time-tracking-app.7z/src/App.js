import './App.css';
import Timer from './Timer';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        Time Tracking App
        <Timer/>
      </header>
    </div>
  );
}

export default App;
